# Apache PHP7.2.x MariaDB install on Centos7 Script

## STEP1.DownLoad File

Download the file \(apmsetup.sh\) to the /root location of Centso7 Linux \(RedHat family\).

## STEP2.Grants execute permission to the downloaded file.

shell&gt; chmod 701 /root/apmsetup.sh

## STEP3.Execute the file.

shell&gt; /root/apmsetup.sh

