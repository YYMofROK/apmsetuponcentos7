# Table of contents

* [Apache PHP7.2.x MariaDB install on Centos7 Script](README.md)

